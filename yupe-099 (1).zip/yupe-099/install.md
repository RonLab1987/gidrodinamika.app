Подробная инструкция по установке:
[http://yupe.ru/docs/install.html](http://yupe.ru/docs/install.html)

Настройка операционной системы (Ubuntu):
[http://yupe.ru/docs/ubuntu.html](http://yupe.ru/docs/ubuntu.html)

После установки
---------------

- [Расскажите нам о новом сайте на Юпи!](http://yupe.ru/contacts). Нам будет очень приятно!
- [Сообщайте об ошибках, замечаниях или предложениях](https://github.com/yupe/yupe/issues)
- Расскажите друзьям о Юпи!
- [Следите за обновлениями в twitter](https://twitter.com/YupeCms)
- [Общайтесь на форуме](http://yupe.ru/talk/)
- [Помогайте проекту](http://yupe.ru/docs/yupe/assistance.project.html)
- [Присылайте pull requests](https://github.com/yupe/yupe/pulls) (патчи)
- Отдыхайте и наслаждайтесь жизнью!

При возникновении проблем [мы](http://amylabs.ru/contact) готовы вам помочь!