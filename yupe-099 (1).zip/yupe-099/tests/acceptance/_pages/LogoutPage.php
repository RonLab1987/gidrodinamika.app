<?php
namespace tests\acceptance\pages;

class LogoutPage
{
    public static $URL = '/logout';

    public static $linkLabel = 'Выйти';
}
