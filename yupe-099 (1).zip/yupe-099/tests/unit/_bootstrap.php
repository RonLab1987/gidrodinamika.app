<?php

defined("VENDOR_DIR") or define("VENDOR_DIR", dirname(__FILE__) . '/../../vendor/');
defined("APPLICATION_DIR") or define("APPLICATION_DIR", dirname(__FILE__) . '/../../protected/');
defined("MOCKED_DIR") or define("MOCKED_DIR", dirname(__FILE__) . '/_mocked/');

require_once VENDOR_DIR . 'yiisoft/yii/framework/yiit.php';
