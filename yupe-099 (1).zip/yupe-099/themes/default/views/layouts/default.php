<?php $this->beginContent('//layouts/main'); ?>
<!-- content -->
<section class="col-sm-12 content">
    <?= $content; ?>
</section>
<!-- content end-->
<?php $this->endContent(); ?>
