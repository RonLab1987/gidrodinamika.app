<?php
class DefautThemeEvents
{
    CONST BODY_END = 'template.body.end';

    CONST BODY_START = 'template.body.start';

    CONST HEAD_END = 'template.head.end';

    CONST HEAD_START = 'template.head.start';
}
