Наша команда
============

- Опейкин Андрей [http://amylabs.ru/](http://amylabs.ru/)
- Седов Николай [http://amylabs.ru/](http://amylabs.ru/)
- Тимашов Максим  apexwire@amylabs.ru
- Кучеров Антон [http://idexter.ru/](http://idexter.ru/)
- Плаксунов Юрий [http://amylabs.ru/](http://amylabs.ru/)
- Чемезов Михаил [http://vk.com/m.chemezov](http://vk.com/m.chemezov)
- Филимонов Олег olegsabian@gmail.com

[Ждем только тебя !](http://yupe.ru/contacts)
