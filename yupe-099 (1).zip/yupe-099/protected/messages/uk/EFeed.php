<?php

return [
    'Feed version not supported' => 'Версії стрічки не підтримуються',
    'For RSS 1.0 specifications link element should be add per item' => 'В спецификації RSS 1.0 елемент повинен будети додадний для кожної сутоності',
    'Link Element is not set and it is required for RSS 1.0 to be used as about attribute of item' => 'Link Element не встановлено. Вказаний елемент обов´язковий для стандарту RSS 1.0',
    'No feed items configured' => 'Сутності не налаштовані',
    'No items have been set' => 'Сутності не встановлені',
];
