<?php

class SiteMapEvents
{
    const BEFORE_GENERATE = 'sitemap.before.generate';
} 
