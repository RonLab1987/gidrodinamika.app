<?php
class StoreEvents
{
    const CATEGORY_AFTER_SAVE = 'category.after.save';
}