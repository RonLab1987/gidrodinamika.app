<?php
namespace yupe\components;

use Symfony\Component\EventDispatcher\Event as MainEvent;

/**
 * Class Event
 * @package yupe\components
 */
class Event extends MainEvent
{

}
