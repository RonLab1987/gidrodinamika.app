<?php

interface ICommentAllowed
{
    public function isCommentAllowed();
}